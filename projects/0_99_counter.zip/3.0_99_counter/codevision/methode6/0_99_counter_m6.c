#include <delay.h>
#include <mega32a.h>
#include <stdio.h>

void main() {

  int i = 0;

  DDRA = 0xFF;
  PORTA = 0x00;

  while (1) {
    for (i = 0; i < 100; i++) {
      PORTA = (i % 10) + 16;
      delay_ms(50);

      PORTA = (i / 10) + 32;
      delay_ms(50);
    };
  }
}